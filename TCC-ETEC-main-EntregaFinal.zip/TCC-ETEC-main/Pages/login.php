<?php
session_start();
require_once '../Config/conexao.php';

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

if ($email === '' || $senha === '') {
    header('Location: index.php?erro=campos_vazios');
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: index.php?erro=email_invalido');
    exit;
}

try {
    $pdo = Conexao::conectar();
    $stmt = $pdo->prepare('SELECT * FROM usuario WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if (!$usuario || !password_verify($senha, $usuario['senha'])) {
        header('Location: index.php?erro=login_invalido');
        exit;
    }

    $_SESSION['usuario'] = [
        'id' => $usuario['id_usuario'],
        'nome' => $usuario['nome'] ?? '',
        'email' => $usuario['email'] ?? '',
        'idioma' => $usuario['idioma'] ?? '',
        'pais' => $usuario['pais_origem'] ?? '',
        'status' => $usuario['status_residencia'] ?? '',
        'apelido' => $usuario['apelido'] ?? ''
    ];

    header('Location: mainPage.php');
    exit;
} catch (Throwable $e) {
    header('Location: index.php?erro=erro_sistema');
    exit;
}
?>
