<?php
session_start();
require_once '../Config/conexao.php';

$nome = trim($_POST['nome'] ?? '');
$status = trim($_POST['status'] ?? '');
$apelido = trim($_POST['apelido'] ?? '');
$email = trim($_POST['email'] ?? '');
$idioma = trim($_POST['idioma'] ?? '');
$pais = trim($_POST['pais'] ?? '');
$senha = $_POST['senha'] ?? '';
$confirmar = $_POST['confirmar_senha'] ?? '';

if ($nome === '' || $status === '' || $email === '' || $senha === '' || $confirmar === '') {
    header('Location: formUsuario.php?erro=campos_vazios');
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: formUsuario.php?erro=email_invalido');
    exit;
}
if ($senha !== $confirmar) {
    header('Location: formUsuario.php?erro=senha_diferente');
    exit;
}

try {
    $pdo = Conexao::conectar();
    $hash = password_hash($senha, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO usuario (nome, status_residencia, apelido, email, idioma, pais_origem, senha) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$nome, $status, $apelido, $email, $idioma, $pais, $hash]);

    header('Location: index.php?msg=cadastro_ok');
    exit;
} catch (Throwable $e) {
    header('Location: formUsuario.php?erro=erro_cadastro');
    exit;
}
?>
