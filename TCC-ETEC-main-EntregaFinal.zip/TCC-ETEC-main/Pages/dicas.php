<?php
require_once '../Config/auth.php';
require_once '../Config/nav.php';
require_once '../Services/dicaService.php';
$service = new DicaService();
$id_usuario = $_SESSION['usuario']['id'] ?? null;
$categorias = ['Todas','Trabalho','Moradia','Saúde','Educação','Documentos','Geral'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $id_usuario) {
    $texto = trim($_POST['texto'] ?? '');
    $categoria = trim($_POST['categoria'] ?? 'Geral');
    if ($texto !== '') { $service->cadastrar($id_usuario, $texto, $categoria); }
    header('Location: dicas.php?categoria='.urlencode($categoria)); exit;
}
$busca = trim($_GET['busca'] ?? '');
$categoriaAtual = trim($_GET['categoria'] ?? 'Todas');
$dicas = $service->listar($busca, $categoriaAtual);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php require_once '../Config/header.php'; ?>
    <title>Dicas - EasyMigra</title>
    <link rel="stylesheet" href="../css/style_dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="app-header-dicas">
        <a href="mainPage.php" class="back-link"><i class="fa-solid fa-arrow-left"></i></a>
        <h2>Dicas da Comunidade</h2>
        <i class="fa-solid fa-star"></i>
    </header>

    <nav class="dicas-tabs">
        <?php foreach ($categorias as $cat): ?>
            <?php $url = 'dicas.php?categoria='.urlencode($cat).'&busca='.urlencode($busca); ?>
            <a class="tab <?= $cat === $categoriaAtual ? 'active' : '' ?>" href="<?= $url ?>"><?= htmlspecialchars($cat) ?></a>
        <?php endforeach; ?>
    </nav>

    <main class="page">
        <form class="search-box" method="GET">
            <input type="hidden" name="categoria" value="<?= htmlspecialchars($categoriaAtual) ?>">
            <input type="text" name="busca" placeholder="Pesquisar dicas..." value="<?= htmlspecialchars($busca) ?>">
            <button class="primary-btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
        </form>

        <div class="feed-container">
            <?php if (empty($dicas)): ?>
                <p class="empty-state">Nenhuma dica encontrada para esse filtro.</p>
            <?php else: ?>
                <?php foreach($dicas as $d): ?>
                    <article class="dica-card">
                        <div class="dica-header">
                            <div class="avatar-placeholder"><?= strtoupper(substr($d['autor'] ?? 'U', 0, 1)); ?></div>
                            <div>
                                <strong><?= htmlspecialchars($d['autor'] ?? 'Usuário'); ?></strong><br>
                                <small class="muted"><?= date('d/m/Y', strtotime($d['data_publicacao'] ?? date('Y-m-d'))); ?></small>
                            </div>
                        </div>
                        <span class="category-pill"><?= htmlspecialchars($d['categoria'] ?? 'Geral') ?></span>
                        <p><?= htmlspecialchars($d['texto'] ?? '') ?></p>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <button class="btn-compartilhar" onclick="document.getElementById('modalDica').style.display='flex'"><i class="fa-solid fa-plus"></i> Compartilhar dica</button>
    </main>

    <div id="modalDica" class="modal-container">
        <div class="modal-content">
            <h3>Nova dica</h3>
            <form method="POST">
                <select name="categoria">
                    <?php foreach (array_slice($categorias,1) as $cat): ?><option value="<?= $cat ?>"><?= $cat ?></option><?php endforeach; ?>
                </select>
                <textarea name="texto" placeholder="Compartilhe uma orientação útil..." required></textarea>
                <div class="modal-buttons">
                    <button type="button" class="secondary-btn" onclick="document.getElementById('modalDica').style.display='none'">Cancelar</button>
                    <button type="submit" class="primary-btn" style="background:#16a085">Publicar</button>
                </div>
            </form>
        </div>
    </div>
    <?php renderBottomNav('dicas'); ?>
    <script>window.onclick=e=>{const m=document.getElementById('modalDica'); if(e.target===m)m.style.display='none';}</script>
</body>
</html>
