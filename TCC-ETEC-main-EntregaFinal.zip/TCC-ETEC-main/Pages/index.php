<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (isset($_SESSION['usuario'])) {
    header('Location: mainPage.php');
    exit;
}
$erro = $_GET['erro'] ?? '';
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php require_once '../Config/header.php'; ?>
    <title>EasyMigra - Início</title>
    <style>
        *{box-sizing:border-box}
        body{margin:0;font-family:Arial,sans-serif;background:linear-gradient(135deg,#4e73df,#224abe);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;color:#1f2937}
        .container{width:100%;max-width:920px;background:#fff;border-radius:24px;box-shadow:0 12px 40px rgba(0,0,0,.22);overflow:hidden;display:grid;grid-template-columns:1fr 1fr}
        .hero{background:linear-gradient(160deg,#eef3ff,#ffffff);padding:42px 34px;display:flex;flex-direction:column;justify-content:center}
        .brand{font-size:34px;font-weight:800;color:#224abe;margin:0 0 10px}
        .subtitle{font-size:18px;line-height:1.45;color:#4b5563;margin:0 0 24px}
        .benefits{display:grid;gap:12px;margin-top:12px}
        .benefit{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:13px 14px;color:#374151}
        .panel{padding:38px 34px;display:flex;flex-direction:column;justify-content:center}
        h2{margin:0 0 8px;color:#111827}.muted{margin:0 0 22px;color:#6b7280}
        input{width:100%;padding:13px;margin:8px 0 14px;border-radius:10px;border:1px solid #d1d5db;font-size:15px}
        input:focus{border-color:#4e73df;outline:none;box-shadow:0 0 0 3px rgba(78,115,223,.15)}
        button,.btn{display:block;width:100%;text-align:center;padding:13px;border-radius:10px;border:0;text-decoration:none;font-weight:700;cursor:pointer;font-size:15px}
        button{background:#4e73df;color:#fff}.btn-create{background:#16a34a;color:#fff;margin-top:12px}.btn-secondary{background:#eef2ff;color:#224abe;margin-top:10px}
        .error,.success{padding:11px;border-radius:10px;margin-bottom:14px;font-size:14px}.error{background:#fee2e2;color:#991b1b}.success{background:#dcfce7;color:#166534}
        .divider{display:flex;align-items:center;gap:10px;color:#9ca3af;margin:17px 0}.divider:before,.divider:after{content:"";height:1px;background:#e5e7eb;flex:1}
        @media(max-width:760px){.container{grid-template-columns:1fr}.hero{padding:30px 24px}.panel{padding:28px 24px}.brand{font-size:30px}}
    </style>
</head>
<body>
    <main class="container">
        <section class="hero">
            <h1 class="brand">EasyMigra</h1>
            <p class="subtitle">Uma plataforma para apoiar imigrantes no acesso a documentos, serviços públicos, prazos e dicas úteis no Brasil.</p>
            <div class="benefits">
                <div class="benefit">✓ Consulte documentos de residência, trabalho, saúde e educação</div>
                <div class="benefit">✓ Organize prazos importantes na agenda</div>
                <div class="benefit">✓ Compartilhe e encontre dicas da comunidade</div>
            </div>
        </section>
        <section class="panel">
            <h2>Acesse seu perfil</h2>
            <p class="muted">Entre na sua conta ou crie um perfil para começar.</p>

            <?php if ($msg === 'conta_excluida'): ?>
                <div class="success">Conta excluída com sucesso. Crie um novo perfil ou entre com outra conta.</div>
            <?php elseif ($msg === 'cadastro_ok'): ?>
                <div class="success">Cadastro criado com sucesso. Faça login para continuar.</div>
            <?php elseif ($msg === 'login_necessario'): ?>
                <div class="error">Faça login ou crie um perfil para acessar o sistema.</div>
            <?php endif; ?>

            <?php if ($erro === 'campos_vazios'): ?>
                <div class="error">Preencha todos os campos.</div>
            <?php elseif ($erro === 'email_invalido'): ?>
                <div class="error">Email inválido.</div>
            <?php elseif ($erro === 'login_invalido'): ?>
                <div class="error">Email ou senha incorretos.</div>
            <?php elseif ($erro === 'erro_sistema'): ?>
                <div class="error">Ocorreu um erro no sistema. Verifique o banco de dados.</div>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="senha" placeholder="Senha" required>
                <button type="submit">Entrar</button>
            </form>
            <div class="divider">ou</div>
            <a class="btn btn-create" href="formUsuario.php">Criar perfil</a>
            <a class="btn btn-secondary" href="mainPage.php">Continuar após login</a>
        </section>
    </main>
</body>
</html>
