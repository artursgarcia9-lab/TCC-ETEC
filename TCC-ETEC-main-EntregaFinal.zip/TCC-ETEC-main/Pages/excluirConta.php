<?php
require_once '../Config/auth.php';
require_once '../Config/conexao.php';

$idUsuario = $_SESSION['usuario']['id'] ?? null;

try {
    if ($idUsuario) {
        $pdo = Conexao::conectar();
        $stmt = $pdo->prepare('DELETE FROM usuario WHERE id_usuario = ?');
        $stmt->execute([$idUsuario]);
    }
} catch (Throwable $e) {
    // Mesmo que a exclusão no banco falhe, a sessão local é encerrada para voltar ao início.
}

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();

header('Location: index.php?msg=conta_excluida');
exit;
?>
