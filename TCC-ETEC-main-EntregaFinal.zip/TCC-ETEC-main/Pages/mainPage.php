<?php
require_once '../Config/auth.php';
require_once '../Config/nav.php';
require_once '../Services/notificacaoService.php';
$usuario = $_SESSION['usuario'];
$notificacaoService = new NotificacaoService();
$notificacoes = $notificacaoService->listar($usuario['id'] ?? null);
$totalNotificacoes = $notificacaoService->contarNaoLidas($usuario['id'] ?? null);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php require_once '../Config/header.php'; ?>
    <title>EasyMigra - Início</title>
    <link rel="stylesheet" href="../css/style_dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="app-header">
        <button class="icon-btn" onclick="abrirMenu()" aria-label="Abrir menu"><i class="fa-solid fa-bars"></i></button>
        <div class="brand">
            <div class="brand-logo"><i class="fa-solid fa-globe-americas"></i></div>
            <div><strong>EasyMigra</strong><small>Apoio para sua vida no Brasil</small></div>
        </div>
        <button class="icon-btn" onclick="alternarNotificacoes()" aria-label="Ver notificações">
            <i class="fa-solid fa-bell"></i>
            <span class="badge"><?= $totalNotificacoes ?></span>
        </button>
    </header>

    <aside id="drawerMenu" class="drawer" onclick="fecharMenu(event)">
        <div class="drawer-panel">
            <h2>Menu</h2>
            <p class="muted">Olá, <?= htmlspecialchars($usuario['nome'] ?? 'usuário') ?></p>
            <a href="mainPage.php"><i class="fa-solid fa-house"></i> Início</a>
            <a href="documentos.php"><i class="fa-solid fa-file-lines"></i> Documentos</a>
            <a href="orgaos.php"><i class="fa-solid fa-location-dot"></i> Órgãos públicos</a>
            <a href="agenda.php"><i class="fa-solid fa-calendar-days"></i> Agenda</a>
            <a href="dicas.php"><i class="fa-solid fa-star"></i> Dicas</a>
            <a href="chat.php"><i class="fa-solid fa-comment"></i> Chat de apoio</a>
            <a href="perfil.php"><i class="fa-solid fa-user-gear"></i> Perfil e configurações</a>
        </div>
    </aside>

    <section id="painelNotificacoes" class="notification-panel">
        <h3>Notificações</h3>
        <?php foreach ($notificacoes as $n): ?>
            <div class="notification-card">
                <strong><?= htmlspecialchars($n['titulo']) ?></strong>
                <p class="muted"><?= htmlspecialchars($n['mensagem']) ?></p>
                <small><?= htmlspecialchars($n['data']) ?></small>
            </div>
        <?php endforeach; ?>
        <p><a href="notificacoes.php" class="secondary-btn" style="display:inline-block;margin-top:10px;">Ver todas</a></p>
    </section>

    <main class="page">
        <section class="welcome-banner">
            <div>
                <h1>Bem-vindo ao EasyMigra!</h1>
                <p>Informação, orientação e apoio para imigrantes no Brasil.</p>
                <small>Olá, <?= htmlspecialchars($usuario['nome'] ?? 'usuário') ?></small>
            </div>
            <div class="welcome-avatar"><i class="fa-solid fa-user"></i></div>
        </section>

        <section class="menu-grid">
            <a href="documentos.php" class="menu-card"><i class="fa-solid fa-file-invoice icon-green"></i><span>Documentos</span></a>
            <a href="orgaos.php" class="menu-card"><i class="fa-solid fa-location-dot icon-purple"></i><span>Órgãos</span></a>
            <a href="agenda.php" class="menu-card"><i class="fa-solid fa-calendar-days icon-orange"></i><span>Agenda</span></a>
            <a href="dicas.php" class="menu-card"><i class="fa-solid fa-comments icon-green"></i><span>Dicas</span></a>
            <a href="chat.php" class="menu-card"><i class="fa-solid fa-comment icon-blue"></i><span>Chat de Apoio</span></a>
            <a href="perfil.php" class="menu-card"><i class="fa-solid fa-user-gear icon-blue"></i><span>Perfil</span></a>
        </section>

        <section class="info-bar">
            <i class="fa-solid fa-circle-info"></i>
            <p>Encontre aqui tudo o que você precisa para regularizar sua vida e se integrar ao Brasil.</p>
        </section>
    </main>

    <?php renderBottomNav('inicio'); ?>
    <script>
        function abrirMenu(){ document.getElementById('drawerMenu').style.display='block'; }
        function fecharMenu(event){ if(event.target.id === 'drawerMenu') event.target.style.display='none'; }
        function alternarNotificacoes(){ const p=document.getElementById('painelNotificacoes'); p.style.display = p.style.display === 'block' ? 'none' : 'block'; }
    </script>
</body>
</html>
