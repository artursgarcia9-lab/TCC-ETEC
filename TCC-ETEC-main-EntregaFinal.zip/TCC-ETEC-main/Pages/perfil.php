<?php
require_once '../Config/auth.php';
require_once '../Config/nav.php';
require_once '../Config/conexao.php';

$salvo = false;
$erro = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $idioma = trim($_POST['idioma'] ?? '');
    $pais = trim($_POST['pais'] ?? '');
    $status = trim($_POST['status'] ?? '');
    $idUsuario = $_SESSION['usuario']['id'] ?? null;

    if ($idUsuario && $nome !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $pdo = Conexao::conectar();
            $stmt = $pdo->prepare('UPDATE usuario SET nome = ?, email = ?, idioma = ?, pais_origem = ?, status_residencia = ? WHERE id_usuario = ?');
            $stmt->execute([$nome, $email, $idioma, $pais, $status, $idUsuario]);

            $_SESSION['usuario']['nome'] = $nome;
            $_SESSION['usuario']['email'] = $email;
            $_SESSION['usuario']['idioma'] = $idioma;
            $_SESSION['usuario']['pais'] = $pais;
            $_SESSION['usuario']['status'] = $status;
            $salvo = true;
        } catch (Throwable $e) {
            $erro = true;
        }
    } else {
        $erro = true;
    }
}

$u = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php require_once '../Config/header.php'; ?>
    <title>Perfil - EasyMigra</title>
    <link rel="stylesheet" href="../css/style_dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="app-header-profile">
        <a href="mainPage.php" class="back-link"><i class="fa-solid fa-arrow-left"></i></a>
        <h2>Perfil e Configurações</h2>
        <i class="fa-solid fa-user-gear"></i>
    </header>

    <main class="page">
        <section class="profile-card">
            <div style="display:flex;align-items:center;gap:15px">
                <div class="welcome-avatar" style="width:66px;height:66px;font-size:26px"><i class="fa-solid fa-user"></i></div>
                <div>
                    <h2 style="margin:0"><?= htmlspecialchars($u['nome'] ?? 'Usuário') ?></h2>
                    <p class="muted" style="margin:4px 0"><?= htmlspecialchars($u['email'] ?? '') ?></p>
                </div>
            </div>
        </section>

        <?php if($salvo): ?>
            <section class="info-bar"><i class="fa-solid fa-check"></i><p>Perfil atualizado com sucesso.</p></section>
        <?php elseif($erro): ?>
            <section class="info-bar" style="background:#fee2e2;color:#991b1b"><i class="fa-solid fa-triangle-exclamation"></i><p>Não foi possível salvar. Verifique os dados.</p></section>
        <?php endif; ?>

        <section class="profile-card" style="margin-top:14px">
            <h3>Dados do usuário</h3>
            <form class="profile-form" method="POST">
                <input name="nome" placeholder="Nome" value="<?= htmlspecialchars($u['nome'] ?? '') ?>" required>
                <input name="email" type="email" placeholder="Email" value="<?= htmlspecialchars($u['email'] ?? '') ?>" required>
                <input name="idioma" placeholder="Idioma preferido" value="<?= htmlspecialchars($u['idioma'] ?? '') ?>">
                <input name="pais" placeholder="País de origem" value="<?= htmlspecialchars($u['pais'] ?? '') ?>">
                <input name="status" placeholder="Status de residência" value="<?= htmlspecialchars($u['status'] ?? '') ?>">
                <button class="primary-btn" type="submit">Salvar configurações</button>
            </form>
        </section>

        <section class="profile-card profile-list" style="margin-top:14px">
            <a href="notificacoes.php"><i class="fa-solid fa-bell"></i> Notificações</a>
            <a href="uploadArquivo.php"><i class="fa-solid fa-upload"></i> Meus arquivos</a>
            <a href="deletarConta.php" class="danger-link"><i class="fa-solid fa-trash"></i> Excluir conta</a>
            <a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Sair</a>
        </section>
    </main>
    <?php renderBottomNav('perfil'); ?>
</body>
</html>
