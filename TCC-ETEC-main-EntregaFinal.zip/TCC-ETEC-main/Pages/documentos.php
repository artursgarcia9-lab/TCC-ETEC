<?php require_once '../Config/auth.php'; require_once '../Config/nav.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php require_once '../Config/header.php'; ?>
    <title>Documentos - EasyMigra</title>
    <link rel="stylesheet" href="../css/style_dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="app-header-docs">
        <a href="mainPage.php" class="back-link"><i class="fa-solid fa-arrow-left"></i></a>
        <h2>Documentos</h2>
        <i class="fa-solid fa-file-lines"></i>
    </header>
    <main class="page">
        <p class="muted">Encontre informações sobre os principais documentos no Brasil.</p>
        <div class="nav-list">
            <a href="detalhes_residencia.php" class="nav-card"><div class="card-icon-circle green"><i class="fa-solid fa-file-contract"></i></div><div class="card-info"><strong>Residência</strong><span>Documentos para viver legalmente no Brasil.</span></div><i class="fa-solid fa-chevron-right arrow"></i></a>
            <a href="detalhes_trabalho.php" class="nav-card"><div class="card-icon-circle blue"><i class="fa-solid fa-briefcase"></i></div><div class="card-info"><strong>Trabalho</strong><span>Documentos necessários para trabalhar.</span></div><i class="fa-solid fa-chevron-right arrow"></i></a>
            <a href="detalhes_saude.php" class="nav-card"><div class="card-icon-circle red"><i class="fa-solid fa-heart-pulse"></i></div><div class="card-info"><strong>Saúde</strong><span>Acesso ao SUS e serviços de saúde.</span></div><i class="fa-solid fa-chevron-right arrow"></i></a>
            <a href="detalhes_educacao.php" class="nav-card"><div class="card-icon-circle yellow"><i class="fa-solid fa-graduation-cap"></i></div><div class="card-info"><strong>Educação</strong><span>Matrícula em escolas, diplomas e certificações.</span></div><i class="fa-solid fa-chevron-right arrow"></i></a>
        </div>
    </main>
    <?php renderBottomNav('documentos'); ?>
</body>
</html>
