<?php
function renderBottomNav($active = 'inicio') {
    $items = [
        'inicio' => ['mainPage.php','fa-house','Início'],
        'documentos' => ['documentos.php','fa-file-lines','Documentos'],
        'agenda' => ['agenda.php','fa-calendar-days','Agenda'],
        'dicas' => ['dicas.php','fa-star','Dicas'],
        'perfil' => ['perfil.php','fa-user','Perfil'],
    ];
    echo '<nav class="bottom-nav">';
    foreach ($items as $key => $item) {
        $class = $key === $active ? 'nav-item active' : 'nav-item';
        echo '<a href="'.$item[0].'" class="'.$class.'"><i class="fa-solid '.$item[1].'"></i><span>'.$item[2].'</span></a>';
    }
    echo '</nav>';
}
?>
