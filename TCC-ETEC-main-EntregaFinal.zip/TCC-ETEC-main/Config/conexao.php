<?php
class Conexao {
    private static ?PDO $conn = null;

    public static function conectar(): PDO {
        if (self::$conn === null) {
            $host = 'localhost';
            $dbname = 'bd_tcc';
            $usuario = 'root';
            $senha = '';

            try {
                self::$conn = new PDO(
                    "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
                    $usuario,
                    $senha,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                    ]
                );
            } catch (PDOException $e) {
                die('Erro ao conectar com o banco de dados: ' . $e->getMessage());
            }
        }
        return self::$conn;
    }
}
?>
