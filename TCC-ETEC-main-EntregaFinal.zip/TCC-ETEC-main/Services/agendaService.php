<?php
class AgendaService {
    public function listarPorUsuario($id_usuario){ return []; }
    public function cadastrar($id_usuario,$data_evento,$descricao){ return true; }
    public function excluir($id_agenda,$id_usuario){ return true; }
}
?>
