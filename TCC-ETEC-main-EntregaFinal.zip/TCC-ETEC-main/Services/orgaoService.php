<?php
class OrgaoService {
    public function listar(){ return [
        ['nome'=>'Polícia Federal','endereco'=>'Av. Paulista, 1357 - Bela Vista, São Paulo - SP','contato'=>'194'],
        ['nome'=>'CRAS - Centro de Referência','endereco'=>'R. da Consolação, 123 - Consolação, São Paulo - SP','contato'=>'156'],
        ['nome'=>'Receita Federal','endereco'=>'Av. Prestes Maia, 733 - Luz, São Paulo - SP','contato'=>'146']
    ]; }
    public function buscar($termo){
        $termo=mb_strtolower($termo); return array_values(array_filter($this->listar(), fn($o)=>str_contains(mb_strtolower($o['nome'].' '.$o['endereco']),$termo)));
    }
}
?>
