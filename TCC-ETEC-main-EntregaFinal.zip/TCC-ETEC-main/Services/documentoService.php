<?php
class DocumentoService {
    public function listar(){ return []; }
    public function buscarPorTipo($termo){ return []; }
}
?>
