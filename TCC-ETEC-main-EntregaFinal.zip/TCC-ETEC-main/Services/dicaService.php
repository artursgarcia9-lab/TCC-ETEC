<?php
class DicaService {
    private string $arquivo;
    public function __construct() {
        $this->arquivo = __DIR__ . '/../data/dicas.json';
        if (!file_exists($this->arquivo)) {
            $iniciais = [
                ['id_dica'=>1,'autor'=>'Equipe EasyMigra','categoria'=>'Trabalho','texto'=>'Guarde cópias digitais dos seus documentos antes de procurar uma vaga. Isso facilita cadastros e entrevistas.','data_publicacao'=>date('Y-m-d')],
                ['id_dica'=>2,'autor'=>'Equipe EasyMigra','categoria'=>'Saúde','texto'=>'Para usar o SUS, procure uma Unidade Básica de Saúde próxima e leve documento de identificação e comprovante de endereço.','data_publicacao'=>date('Y-m-d')],
                ['id_dica'=>3,'autor'=>'Equipe EasyMigra','categoria'=>'Moradia','texto'=>'Antes de alugar um imóvel, confirme valores de condomínio, contas incluídas e regras do contrato.','data_publicacao'=>date('Y-m-d')]
            ];
            file_put_contents($this->arquivo, json_encode($iniciais, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
        }
    }
    private function ler(): array { return json_decode(file_get_contents($this->arquivo), true) ?: []; }
    private function salvar(array $dicas): void { file_put_contents($this->arquivo, json_encode($dicas, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); }
    public function listar(string $busca = '', string $categoria = 'Todas'): array {
        $dicas = $this->ler();
        usort($dicas, fn($a,$b) => strtotime($b['data_publicacao']) <=> strtotime($a['data_publicacao']));
        $busca = mb_strtolower(trim($busca));
        $categoria = trim($categoria ?: 'Todas');
        return array_values(array_filter($dicas, function($d) use ($busca,$categoria){
            $okCategoria = ($categoria === 'Todas') || (mb_strtolower($d['categoria'] ?? '') === mb_strtolower($categoria));
            $texto = mb_strtolower(($d['texto'] ?? '').' '.($d['autor'] ?? '').' '.($d['categoria'] ?? ''));
            $okBusca = $busca === '' || str_contains($texto, $busca);
            return $okCategoria && $okBusca;
        }));
    }
    public function cadastrar($id_usuario, string $texto, string $categoria = 'Geral'): void {
        $dicas = $this->ler();
        $dicas[] = [
            'id_dica' => count($dicas) ? max(array_column($dicas, 'id_dica')) + 1 : 1,
            'autor' => $_SESSION['usuario']['nome'] ?? 'Usuário',
            'categoria' => $categoria ?: 'Geral',
            'texto' => $texto,
            'data_publicacao' => date('Y-m-d')
        ];
        $this->salvar($dicas);
    }
}
?>
