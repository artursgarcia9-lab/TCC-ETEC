<?php
class NotificacaoService {
    public function listar($id_usuario = null) {
        return [
            ['titulo'=>'Prazo importante', 'mensagem'=>'Revise a validade dos seus documentos de residência.', 'data'=>'Hoje'],
            ['titulo'=>'Dica nova', 'mensagem'=>'Veja dicas recentes da comunidade sobre trabalho e moradia.', 'data'=>'Ontem'],
            ['titulo'=>'Segurança', 'mensagem'=>'Mantenha seus dados atualizados na área de perfil.', 'data'=>'Esta semana']
        ];
    }
    public function contarNaoLidas($id_usuario = null) { return count($this->listar($id_usuario)); }
}
?>
