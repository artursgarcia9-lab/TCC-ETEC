<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['usuario'])) {
    // Usuário padrão para testes locais do TCC. Em produção, o login real deve preencher esta sessão.
    $_SESSION['usuario'] = [
        'id' => 1,
        'nome' => 'Usuário EasyMigra',
        'email' => 'usuario@easymigra.com',
        'idioma' => 'Português',
        'pais' => 'Brasil',
        'status' => 'Em regularização'
    ];
}
?>
