USE bd_tcc;

-- Dados iniciais para testar as novas funcionalidades de consulta.
INSERT INTO Fonte_Oficial (id_fonte, nome, url, tipoFonte) VALUES
(1, 'Receita Federal', 'https://www.gov.br/receitafederal', 'Governo'),
(2, 'Polícia Federal', 'https://www.gov.br/pf', 'Governo'),
(3, 'Ministério do Trabalho', 'https://www.gov.br/trabalho-e-emprego', 'Governo')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), url = VALUES(url), tipoFonte = VALUES(tipoFonte);

INSERT INTO Documento (id_documento, tipo, descricao, requisitos, id_fonte) VALUES
(1, 'CPF', 'Orientações gerais para inscrição no CPF.', 'Documento de identificação, dados pessoais e solicitação em canal autorizado.', 1),
(2, 'RNM', 'Orientações gerais sobre Registro Nacional Migratório.', 'Documento de viagem, formulário, comprovantes e agendamento junto à Polícia Federal.', 2),
(3, 'Carteira de Trabalho', 'Orientações para acesso à Carteira de Trabalho Digital.', 'CPF regularizado e cadastro em conta gov.br.', 3)
ON DUPLICATE KEY UPDATE tipo = VALUES(tipo), descricao = VALUES(descricao), requisitos = VALUES(requisitos), id_fonte = VALUES(id_fonte);

INSERT INTO Origem (fk_Documento_id_documento, fk_Fonte_Oficial_id_fonte) VALUES
(1, 1), (2, 2), (3, 3);

INSERT INTO Orgao (id_orgao, nome, endereco, contato) VALUES
(1, 'Polícia Federal', 'Unidade de atendimento mais próxima conforme cidade do usuário', 194),
(2, 'Receita Federal', 'Atendimento presencial ou digital conforme serviço solicitado', 146),
(3, 'CRAS', 'Centro de Referência de Assistência Social do município', 156)
ON DUPLICATE KEY UPDATE nome = VALUES(nome), endereco = VALUES(endereco), contato = VALUES(contato);
